package org.example.entity.bank;

public class CreditCard {
}
