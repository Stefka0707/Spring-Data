package org.example.entity.bank;

public enum CardType {
    GOLD,SILVER
}
